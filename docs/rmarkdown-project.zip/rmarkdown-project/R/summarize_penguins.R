library(palmerpenguins)


# Calculate the mean weight of the penguins -------------------------------

adelie_mean <- penguins %>% filter(species == "Adelie") %>% pull(body_mass_g) %>% mean(na.rm = TRUE) 
chinstrap_mean <- penguins %>% filter(species == "Chinstrap") %>% pull(body_mass_g) %>% mean(na.rm = TRUE) 
gentoo_mean <- penguins %>% filter(species == "Gentoo") %>% pull(body_mass_g) %>% mean(na.rm = TRUE) 


# Summarize the table -----------------------------------------------------

penguins_sum <- penguins %>% 
  filter(!(is.na(sex))) %>% 
  group_by(species, sex) %>% 
  summarize(
    bill_length = mean(bill_length_mm, na.rm = TRUE),
    bill_depth = mean(bill_depth_mm, na.rm = TRUE),
    flipper_length = mean(flipper_length_mm, na.rm = TRUE),
    body_mass = mean(body_mass_g, na.rm = TRUE)
  )