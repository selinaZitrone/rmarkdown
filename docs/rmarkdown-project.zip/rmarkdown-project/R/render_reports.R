library(rmarkdown)

# Render penguin report to all output formats defined in the document
# Reports should be rendered into the rendered_reports folder
render(
  input = "penguin_paper.Rmd",
  output_format = "all",
  output_dir = "rendered_reports/"
)

# Render report to a specific format, changing some output options
# Report is rendered to a different file name
render(
  input = "penguin_paper.Rmd", 
  output_format = "html_document",
  output_dir = "rendered_reports/",
  output_file = "penguins_changed_yaml.html",
  output_options = list(
    code_download = FALSE,
    toc = FALSE
  )
)

# Render parameterised report

# Render for one species specifically
render(
  input = "penguin_parameterized.Rmd", 
  output_format = "all",
  output_dir = "rendered_reports/",
  params = list(
    species = "Gentoo"
  )
)

# Render all species in for loop
# Give every rendered report a separate name with the respective species
for (x in c("Adelie", "Gentoo", "Chinstrap")) {
  render(
    input = "penguin_parameterized.Rmd",
    output_format = "html_document",
    output_file = paste0(x, "_penguins.html"),
    output_dir = "rendered_reports/",
    params = list(
      species = x
    )
  )
}
