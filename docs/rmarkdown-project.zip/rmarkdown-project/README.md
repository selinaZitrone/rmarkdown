# rmarkdown-project

This project contains example R Markdown documents showing the different techniques
we discussed in the workshop.

The poject contains the following documents:

- `penguin_children.Rmd`: An example of a document that includes child documents. 
  Useful if you want to split a long document into multiple short ones and then
  combine them together. The child documents that are included here are located
  in `/children`.
  
- `penguin_paper.Rmd`: The final R Markdown document from the tasks in the workshop.
  Can be rendered to all output formats either via the knit button, or via the render
  functions in `R/render_reports.R`
  
- `penguin_source.Rmd`: An example of a document that sources an external R script. 
  The R script summarizes the penguin data (`R/summarize_penguins.R`) and then
  the R Markdown file uses the already summarized data after sourcing the R script 
  in the setup chunk
  
- `penguin_parameterized.Rmd`: A doument that uses parameters to create an automatic
  report for the separate penguin species. The default parameter value is `"Adelie"`,
  so if you render the file via the Knit button, you will get an output for the Adelie
  penguins. To render the same report for other penguins, have a look at `R/render_reports.R`.
  There you can find functions to render the report for one other penguin species
  or for all 3 penguin species in a for loop.

